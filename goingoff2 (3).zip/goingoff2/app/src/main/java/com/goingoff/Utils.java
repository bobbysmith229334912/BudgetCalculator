package com.goingoff;

public class Utils {
    // Utility methods can be added here
}
