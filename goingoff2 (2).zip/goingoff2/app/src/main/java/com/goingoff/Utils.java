package com.goingoff;

public class Utils {}