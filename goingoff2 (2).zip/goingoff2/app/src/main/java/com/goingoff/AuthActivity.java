package com.goingoff;

public class AuthActivity {}